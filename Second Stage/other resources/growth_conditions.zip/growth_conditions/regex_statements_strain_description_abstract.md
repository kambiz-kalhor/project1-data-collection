# NLP TokensRegex
/optimum/ /at/? /,/? ([ner: NUMBER]+) /°C/ #optimum temp
([ner: NUMBER]+) /°C/ #temp range
/pH/ ([ner: NUMBER]+) #pH



## REGEX to match different fields in the XML abstracts of prokaryotic strains descriptions

#### temperature range and optimum
(\d+(?:[\.]\d+)*)(((?:\-{1,2})|(?:\–{1,2})|(?:\‒{1,2})|(?:\sto\s)|(?:\sand\s))(\d+(?:[\.]\d+)*))*(\s°C\s*|\sdegreeC\s*|\sdegree\sC\s*)


#### pH range and optimum
(\s*pH\s*)(\d+(?:[\.]\d+)*)(((?:\-{1,2})|(?:\–{1,2})|(?:\sto\s)|(?:\sand\s))(\d+(?:[\.]\d+)*))*

#### salinity range and optimum
(\d+(?:[\.]\d+)*)(((?:\-{1,2})|(?:\–{1,2})|(?:\sto\s)|(?:\sand\s))(\d+(?:[\.]\d+)*))*(\s%\s*|\sM\s*)

#### pressure range and optimum
(\d+(?:[\.]\d+)*)(((?:\-{1,2})|(?:\–{1,2})|(?:\sto\s)|(?:\sand\s))(\d+(?:[\.]\d+)*))*(\sMpa\s*|\sbar\s*)

#### oxygen range and optimum
(\d+(?:[\.]\d+)*)(((?:\-{1,2})|(?:\–{1,2})|(?:\sto\s)|(?:\sand\s))(\d+(?:[\.]\d+)*))*(\s%\s*)

#### cell dimension
(\d+(?:[\.]\d+)*)(((?:\-{1,2})|(?:\–{1,2})|(?:\sto\s)|(?:\sand\s))(\d+(?:[\.]\d+)*))*(\smm\s*)|(\smicron\s*)|(\slenght\s*)|(\swidth\s*)

#### GC content
(\d+(?:[\.]\d+)*)(((?:\-{1,2})|(?:\–{1,2})|(?:\sto\s)|(?:\sand\s))(\d+(?:[\.]\d+)*))*(\smol%\s*)

#### generation time


#### doubling time
